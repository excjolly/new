import React from 'react';

const Home = () => <>This is HomePage.</>;

export default Home;
